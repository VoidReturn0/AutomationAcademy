"""
Riv backup - Training Module
Module generated from PDF processing
"""

from training_module import TrainingModule

class RivBackupModule(TrainingModule):
    """Training module for Riv backup"""
    
    def __init__(self):
        super().__init__()
        self.module_name = "Riv backup"
        self.description = "Module generated from PDF processing"
        self.estimated_duration = 60
        
        # Learning objectives
        self.learning_objectives = ['Complete the training module successfully']
        
        # Module tasks
        self.tasks = ['Review the material', 'Complete the exercises']
        
        # Module content
        self.content = """PDF Document: Riv Backups.pdf\n==================================================\n\nDocument Information:\nTitle: Fax\nAuthor: Clements, Frank\n\nTotal Pages: 3\n\n\n==================== PAGE 1 ====================\n\n 
 
Creating S7 RIV backup  
 
Summary:  
We create backups before and after an y changes are done to the Riveter PLC. This ensures we 
can undo or redo an y changes based off the effects of the modifications.  
 
Procedure : 
-Verify a ll Simatic manager programs are closed (includ ing VAT tables) or you will receive  this 
error  
 
 
 
 
 
 
-Select File/Archive  
 
 
 
 
 
 
\n\n[NOTE: This page contains 3 image(s) that cannot be extracted as text]\n\n==================== PAGE 2 ====================\n\n 
 
 
-Select current project to archive  
 
 
 
 
 
 
 
-Select file location “D:\8500_OE_SW \20_PLC\10_S7_Ar chive” 
 
-Use the following naming standard for backups:  
 
 
 
 
 
 
 
 
 
 
\n\n[NOTE: This page contains 3 image(s) that cannot be extracted as text]\n\n==================== PAGE 3 ====================\n\n[No text content found on this page]\n\n[NOTE: This page contains 1 image(s) that cannot be extracted as text]\n\n\n==================================================\nEXTRACTION NOTES:\n- Text content has been extracted from the PDF\n- Images, charts, and complex formatting are not included\n- For training modules with visual content, consider:\n  * Manually describing important images in the module content\n  * Creating separate image resources for the module\n  * Using PowerPoint format for better visual content preservation\n"""
    
    def get_instructions(self):
        """Get module instructions"""
        return self.content
    
    def verify_completion(self, task_id):
        """Verify task completion"""
        return True
    
    def get_task_description(self, task_id):
        """Get description for specific task"""
        if 0 <= task_id < len(self.tasks):
            return self.tasks[task_id]
        return "Complete the assigned task."
